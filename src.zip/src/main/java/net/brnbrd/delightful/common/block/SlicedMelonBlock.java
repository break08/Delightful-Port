package net.brnbrd.delightful.common.block;

import net.brnbrd.delightful.Util;
import net.brnbrd.delightful.common.DelightfulConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import java.util.function.Supplier;

import net.neoforged.neoforge.items.ItemHandlerHelper;
import vectorwing.farmersdelight.common.tag.ModTags;
import org.jetbrains.annotations.NotNull;

public class SlicedMelonBlock extends Block implements ISliceable {
    public static final Integer MAX_BITES = 8;
    public static final IntegerProperty BITES = IntegerProperty.create("bites", 1, MAX_BITES);
    private final Supplier<Item> sliceItem;
    private final Supplier<Item> juiceItem;

    public SlicedMelonBlock(Properties pProperties, Supplier<Item> sliceItem, Supplier<Item> juiceItem) {
        super(pProperties);
        this.registerDefaultState(this.stateDefinition.any().setValue(BITES, 1));
        this.sliceItem = sliceItem;
        this.juiceItem = juiceItem;
    }

    @Override
    public @NotNull ItemStack getCloneItemStack(@NotNull LevelReader level, @NotNull BlockPos pos, @NotNull BlockState state) {
        return this.getSliceItem();
    }

    public VoxelShape byBite(BlockState state) {
        return Block.box(0D, 0D, 0D, 16D, this.getHeight(state.getValue(BITES)), 16D);
    }

    @Override
    public @NotNull VoxelShape getShape(@NotNull BlockState pState, @NotNull BlockGetter pLevel, @NotNull BlockPos pPos, @NotNull CollisionContext pContext) {
        return byBite(pState);
    }

    @Override
    public @NotNull VoxelShape getOcclusionShape(@NotNull BlockState pState, @NotNull BlockGetter pLevel, @NotNull BlockPos pPos) {
        return byBite(pState);
    }

    @Override
    public int getMaxBites() {
        return MAX_BITES;
    }

    @Override
    public IntegerProperty getBitesProperty() {
        return BITES;
    }

    @Override
    public int getFirstBiteMod() {
        return -1;
    }

    @Override
    public ItemStack getSliceItem() {
        return Util.getStack(this.sliceItem, 1);
    }

    public ItemStack getJuiceItem() {
        return new ItemStack(this.juiceItem.get());
    }

    @Override
    public BlockState getStateForPlacement(@NotNull BlockPlaceContext context) {
        return this.defaultBlockState();
    }

    @Override
    public @NotNull ItemInteractionResult useItemOn(@NotNull ItemStack stack, @NotNull BlockState state, @NotNull Level level, @NotNull BlockPos pos, Player player, @NotNull InteractionHand hand, @NotNull BlockHitResult hit) {
        ItemStack heldStack = player.getItemInHand(hand);
        if (heldStack.is(ModTags.Items.KNIVES)) {
            return this.cutSlice(level, pos, state, player, hand, hit);
        } else if (heldStack.is(Items.GLASS_BOTTLE) && DelightfulConfig.MELON_JUICING.get()) {
            return this.bottleJuice(level, pos, state, player, hand);
        }
        return this.consumeBite(level, pos, state, player);
    }

    protected ItemInteractionResult consumeBite(Level level, BlockPos pos, BlockState state, Player playerIn) {
        if (!playerIn.canEat(false)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        } else if (!level.isClientSide()) {
            ItemStack sliceStack = this.getSliceItem();
            Item slice = sliceStack.getItem();
            FoodProperties sliceFood = slice.getFoodProperties(sliceStack, playerIn);
            if (sliceFood == null){
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            playerIn.getFoodData().eat(sliceFood);
            if (sliceStack.has(DataComponents.FOOD)) {
                for (FoodProperties.PossibleEffect pair : sliceFood.effects()) {
                    var effect = pair.effect();
                    if (level.random.nextFloat() < pair.probability()) {
                        playerIn.addEffect(new MobEffectInstance(effect));
                    }
                }
            }
            int bites = state.getValue(BITES);
            if (bites == this.getMaxBites()) {
                level.removeBlock(pos, false);
            } else if (bites < this.getMaxBites()) {
                level.setBlock(pos, state.setValue(BITES, bites + 1), 3);
            }
            level.playSound(null, playerIn.blockPosition().above(), SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, 1F, 1F);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide());
    }

    protected ItemInteractionResult cutSlice(Level level, BlockPos pos, BlockState state, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide()) {
            int bites = state.getValue(BITES);
            if (bites == this.getMaxBites()) {
                level.removeBlock(pos, false);
            } else if (bites < this.getMaxBites()) {
                level.setBlock(pos, state.setValue(BITES, bites + 1), 3);
            }
            Direction direction = hit.getDirection();
            Util.dropOrGive(
                    this.getSliceItem(),
                    level,
                    pos,
                    direction.getAxis() == Direction.Axis.Y ? player.getDirection().getOpposite() : direction,
                    player
            );
            level.playSound(null, pos, SoundEvents.PUMPKIN_CARVE, SoundSource.BLOCKS, 1F, 1F);
            player.getItemInHand(hand).hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide());
    }

    protected ItemInteractionResult bottleJuice(Level level, BlockPos pos, BlockState state, Player player, InteractionHand hand) {
        if (!level.isClientSide()) {
            int bites = state.getValue(BITES);
            int bites_left = ((this.getMaxBites() + 1) - bites);
            if (bites_left == 4) {
                level.removeBlock(pos, false);
            } else if (bites_left > 4) {
                level.setBlock(pos, state.setValue(BITES, bites + 4), 3);
            } else {
                return ItemInteractionResult.FAIL;
            }
            player.getItemInHand(hand).shrink(1);
            ItemHandlerHelper.giveItemToPlayer(player, this.getJuiceItem(), 0);
            level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.PLAYERS, 1F, 1F);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(BITES);
    }

    @Override
    public int getAnalogOutputSignal(BlockState blockState, @NotNull Level level, @NotNull BlockPos pos) {
        return this.getMaxBites() - blockState.getValue(BITES);
    }

    @Override
    public boolean hasAnalogOutputSignal(@NotNull BlockState state) {
        return true;
    }

    @Override
    public boolean isPathfindable(@NotNull BlockState state, @NotNull PathComputationType type) {
        return false;
    }
}
